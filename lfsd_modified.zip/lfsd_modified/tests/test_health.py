import pytest


@pytest.mark.anyio
async def test_health_endpoint(client):
    response = await client.get("/healthz")
    assert response.status_code == 200
    payload = response.json()
    assert payload.get("status") == "ok"
    assert "env" in payload