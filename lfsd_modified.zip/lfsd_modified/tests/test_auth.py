import pytest


@pytest.mark.anyio
async def test_token_invalid_credentials(client):
    response = await client.post(
        "/user/token", data={"username": "invalid", "password": "wrong"}
    )
    assert response.status_code == 401


@pytest.mark.anyio
async def test_token_valid_credentials_and_me(client):
    # Use the default fake user 'alice' defined in authentication.py
    response = await client.post(
        "/user/token", data={"username": "alice", "password": "password"}
    )
    assert response.status_code == 200
    data = response.json()
    assert "access_token" in data
    token = data["access_token"]
    # Call protected endpoint
    me = await client.get(
        "/user/me", headers={"Authorization": f"Bearer {token}"}
    )
    assert me.status_code == 200
    me_data = me.json()["data"]
    assert me_data["username"] == "alice"