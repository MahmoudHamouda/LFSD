import pytest
from httpx import AsyncClient

from app import create_app


@pytest.fixture
def anyio_backend() -> str:
    """Configure pytest-asyncio to use the asyncio backend."""
    return "asyncio"


@pytest.fixture
async def client() -> AsyncClient:
    """Provide an HTTPX AsyncClient bound to the FastAPI app for tests."""
    app = create_app()
    async with AsyncClient(app=app, base_url="http://testserver") as ac:
        yield ac