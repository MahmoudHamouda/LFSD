"""
Simplified chat routes for the LFSD API gateway.

This module defines a single endpoint for handling chat requests from users.
It uses a token authentication decorator from the user routes, retrieves
basic financial context for the user, and generates a response via a stubbed
OpenAI client. The resulting response is returned to the caller without
performing any rate limiting or NoSQL logging.
"""

from flask import Blueprint, request, jsonify

from routes.user_routes import token_required
from db import get_db_connection
from shared.openai_client import generate_response
from shared.logging import get_logger


logger = get_logger("chat_service")
chat_blueprint = Blueprint("chat_service", __name__)


@chat_blueprint.route("/users/<int:user_id>/chat", methods=["POST"])
@token_required
def handle_chat(user_id):
    """
    Handle a chat request for a specific user.

    The request payload should include a JSON body with a ``query`` field. The
    function fetches the user's financial context (income, expenses, savings,
    debts, preferences) from the relational database and passes this context
    along with the query to a stubbed OpenAI client to generate a response.

    :param user_id: ID of the user making the request (extracted from the URL)
    :returns: JSON response with the generated reply, or an error message
    """
    data = request.json or {}
    query = data.get("query")
    if not query:
        return jsonify({"error": "Query is required"}), 400

    # Retrieve user context from the database
    conn = None
    try:
        conn = get_db_connection()
        cursor = conn.cursor()
        cursor.execute(
            """
            SELECT u.income, u.expenses, COALESCE(s.balance, 0) AS savings,
                   COALESCE(d.principal, 0) AS debts, u.preferences
            FROM Users u
            LEFT JOIN SavingsAccounts s ON u.user_id = s.user_id
            LEFT JOIN Debts d ON u.user_id = d.user_id
            WHERE u.user_id = %s
            """,
            (user_id,),
        )
        context = cursor.fetchone()
    except Exception as e:
        logger.error(f"Database error for user {user_id}: {e}")
        return jsonify({"error": "Database error"}), 500
    finally:
        if conn:
            conn.close()

    if not context:
        return jsonify({"error": "User context not found"}), 404

    formatted = (
        f"Financial Summary:\n"
        f"- Monthly income: {context[0]}\n"
        f"- Monthly expenses: {context[1]}\n"
        f"- Savings: {context[2]}\n"
        f"- Debts: {context[3]}\n"
        f"User Preferences: {context[4]}"
    )

    # Generate a response using the stubbed OpenAI client
    try:
        response = generate_response(query, formatted)
    except Exception as e:
        logger.error(f"Failed to generate response for user {user_id}: {e}")
        return jsonify({"error": "Failed to generate response"}), 500

    return jsonify({"status": "success", "response": response}), 200