"""
Database connection helper for the API gateway.

This module exposes a single function, ``get_db_connection``, which returns a
new PostgreSQL database connection. It reads connection parameters from
environment variables and falls back to sensible defaults for local
development. Other modules should import this function to obtain a
connection rather than duplicating database code.
"""

import os
import psycopg2


def get_db_connection():
    """
    Create and return a new database connection using environment variables.

    The following environment variables are used:
    - ``DB_HOST`` (default: ``localhost``)
    - ``DB_PORT`` (default: ``5432``)
    - ``DB_USER`` (default: ``postgres``)
    - ``DB_PASSWORD`` (default: ``postgres``)
    - ``DB_NAME`` (default: ``financial_app``)

    :returns: A new ``psycopg2`` connection object.
    """
    return psycopg2.connect(
        host=os.getenv("DB_HOST", "localhost"),
        port=int(os.getenv("DB_PORT", 5432)),
        user=os.getenv("DB_USER", "postgres"),
        password=os.getenv("DB_PASSWORD", "postgres"),
        dbname=os.getenv("DB_NAME", "financial_app"),
    )