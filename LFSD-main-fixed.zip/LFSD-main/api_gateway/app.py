from flask import Flask, jsonify

# Import blueprints from the routes package. These blueprints already define
# their own URL paths, so we don't specify url_prefix here.
from routes.user_routes import user_blueprint
from routes.financial_routes import financial_blueprint
from routes.chat_routes import chat_blueprint
from routes.partner_routes import partner_blueprint
from routes.recommendation_routes import recommendation_blueprint
from routes.notification_routes import notification_blueprint
from routes.activity_feed_routes import activity_feed_blueprint
from routes.audit_routes import audit_blueprint


def create_app() -> Flask:
    """
    Factory function to create and configure the Flask application.
    This function registers all blueprints without prefixes so each route
    defines its full path within the blueprint module.

    :return: Configured Flask app instance.
    """
    app = Flask(__name__)

    # Register blueprints. Blueprints encapsulate route definitions and
    # should not be prefixed here because each module specifies its own
    # full route paths. Removing prefixes avoids duplicate path segments.
    app.register_blueprint(user_blueprint)
    app.register_blueprint(financial_blueprint)
    app.register_blueprint(chat_blueprint)
    app.register_blueprint(partner_blueprint)
    app.register_blueprint(recommendation_blueprint)
    app.register_blueprint(notification_blueprint)
    app.register_blueprint(activity_feed_blueprint)
    app.register_blueprint(audit_blueprint)

    @app.route("/health", methods=["GET"])
    def health_check():
        """Simple health check endpoint to verify that the API gateway is running."""
        return jsonify({"status": "success", "message": "API Gateway is running"}), 200

    return app


if __name__ == "__main__":
    # Create the Flask application instance and run it. Debug mode is
    # enabled for development purposes; disable it in production.
    application = create_app()
    application.run(debug=True, port=5000)