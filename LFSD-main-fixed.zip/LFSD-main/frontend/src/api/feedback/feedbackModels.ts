export interface Feedback {
  messageId: string
  userId: string
  feedback: string
  createdAt?: string
}
