"""
Simplified OpenAI client stub.

This module provides basic functions for generating responses and
recommendations. If you have a real OpenAI API key and want to use the
OpenAI service, replace these stub functions with calls to
``openai.ChatCompletion.create``. For development and testing without
external dependencies, these stubs return formatted responses.
"""

import logging

logger = logging.getLogger("openai_client")
DEFAULT_MODEL = "gpt-4"


def generate_response(user_input, context=None, model=DEFAULT_MODEL):
    """
    Generate a simple response for a user input.

    This stub does not call the OpenAI API but returns a formatted echo of
    the query and optional context. It is useful for testing the chat
    functionality without external API dependencies.

    :param user_input: The user's input message.
    :param context: Optional context to guide the response.
    :param model: Ignored in this stub.
    :return: A string representing the assistant's response.
    """
    logger.info(f"Generating stub response for input: {user_input}")
    response = f"(stub) You asked: {user_input}"
    if context:
        # Limit context length to avoid overly long responses
        snippet = context[:200] + ("..." if len(context) > 200 else "")
        response += f"\nContext: {snippet}"
    return response


def summarize_chat(chat_history, model=DEFAULT_MODEL):
    """
    Provide a simple concatenated summary of a chat history.

    This stub joins the messages and returns the first 300 characters. It does
    not call any external API.

    :param chat_history: List of message strings.
    :param model: Ignored in this stub.
    :return: A summary string.
    """
    logger.info(
        f"Summarizing chat history with {len(chat_history)} messages (stub)"
    )
    combined_history = "\n".join(chat_history)
    if len(combined_history) <= 300:
        return combined_history
    return combined_history[:300] + "..."


def generate_recommendation(context, preferences, model=DEFAULT_MODEL):
    """
    Generate a simple recommendation string based on context and preferences.

    This stub returns a formatted description rather than calling the OpenAI API.
    It concisely echoes the inputs so downstream clients can function without
    external dependencies.

    :param context: The user context (e.g. "dinner with friends").
    :param preferences: Preferences as a dictionary (e.g. {"cuisine": "Italian"}).
    :param model: Ignored in this stub.
    :return: A recommendation string.
    """
    logger.info(
        f"Generating stub recommendation for context: {context} with preferences: {preferences}"
    )
    if not preferences:
        prefs_str = "no specific preferences"
    else:
        prefs_str = ", ".join([f"{k} = {v}" for k, v in preferences.items()])
    return (
        f"(stub) Recommendation based on context '{context}' "
        f"with preferences: {prefs_str}"
    )
